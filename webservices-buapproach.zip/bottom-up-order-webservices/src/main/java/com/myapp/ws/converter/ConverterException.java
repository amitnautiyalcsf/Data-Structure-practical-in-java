package com.myapp.ws.converter;

public class ConverterException extends Exception {

	

	public ConverterException(String string, IllegalArgumentException ex) {
		// TODO Auto-generated constructor stub
	}

}
