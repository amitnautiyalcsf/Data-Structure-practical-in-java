@javax.xml.bind.annotation.XmlSchema(namespace = "http://myapp.com/orders/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.myapp.ws;
