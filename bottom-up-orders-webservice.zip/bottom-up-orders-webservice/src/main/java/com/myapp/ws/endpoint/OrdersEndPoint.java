package com.myapp.ws.endpoint;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.myapp.ws.model.Order;
import com.myapp.ws.model.OrderInfoWrapper;
import com.myapp.ws.model.ProductNameWrapper;
import com.myapp.ws.service.OrdersService;

public class OrdersEndPoint {
	
	@Autowired
	private OrdersService ordersService;
	
	private static final String NAMESPACE_URI = "http://myapp.com/orders";

	@PayloadRoot(namespace = NAMESPACE_URI, localPart="ProductNameWrapper")
	@ResponsePayload 
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.myapp.ws.Orders#search(com.myapp.ws.ProductNameWrapper productName)*
	 */
	public OrderInfoWrapper search( ProductNameWrapper productName) {
		
		System.out.println(productName);
		try {
			List<Order> list = ordersService.findByName(productName.getProductName());
			OrderInfoWrapper orderInfoWrapper = new OrderInfoWrapper();
			orderInfoWrapper.getOrder().addAll(list);
  			return orderInfoWrapper;
		} catch (java.lang.Exception ex) {
			ex.printStackTrace();
			throw new RuntimeException(ex);
		}
	}


}
