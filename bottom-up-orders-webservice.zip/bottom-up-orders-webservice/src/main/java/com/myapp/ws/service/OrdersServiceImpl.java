package com.myapp.ws.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.myapp.ws.model.Order;
import com.myapp.ws.repository.OrdersRepository;

public class OrdersServiceImpl implements OrdersService {
	
	@Autowired
	private OrdersRepository ordersRepository;
	
	
	@Override
	public String addNewProduct(Order order) {
		// TODO Auto-generated method stub
		ordersRepository.save(order);
		return order.getProductName();
	}

	@Override
	public List<Order> findByName(String name) {
		// TODO Auto-generated method stub
		return ordersRepository.findByProductName(name);
	}

}
